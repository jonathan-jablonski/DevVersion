![Screenshot](assets/images/hero.png?raw=true ) 


---

## Table of Contents
  * [Summary](#Summary)
  * [Technologies](#technologies)
  * [Challenges](#challenges)
  * [Future Development](#future-development)
  * [Click here to visit the site!](https://podshack.herokuapp.com/)
---

## Summary 
 > 
---

## Technologies
> <b>Design Tools:</b>
> * Figma
  * Keynote
  * Adobe Photoshop
  
> <b>Development Tools:</b>
  * <b>Framework:</b> Material UI
  * MVC structure
  * React
  * Express
  * Node 
  * Passport - Google OAUTH
  * GitHub API
  * MySQL
  * Handlebars
  * Path
  * JavaScript
  * JQuery
  * CSS
  * .env
  * Git
  * Heroku (Heroku build)
---
![Screenshot](assets/images/login.png?raw=true ) 
## Challenges

 1.

---

## Future Development 



---



[Back To Top](#podshack)
