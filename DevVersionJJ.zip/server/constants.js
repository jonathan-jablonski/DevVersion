
// JWT Secret Key , will be used to generate Token (must be a unique key)
const JWT_SECRET = "jhfbjilsehdg/*d-g*f-dsf*+sdfsd";

module.exports = JWT_SECRET;
